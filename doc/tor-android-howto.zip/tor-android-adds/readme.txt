Install AutoMake and AutoConf tool:

	sudo apt-get install autotools-dev
	sudo apt-get install automake
	sudo apt-get install autogen autoconf libtool gettext-base autopoint


Source of statically linked Tor:
https://github.com/guardianproject/tor-android

git clone --recurse-submodules -j8 git://github.com/foo/bar.git
cd bar

or:

git clone --recursive -j8 git://github.com/foo/bar.git
cd bar

or:

git clone git://github.com/foo/bar.git
cd bar
git submodule update --init --recursive



The file was changed (add UDP control socket on localhost:9877 for ping and force exit):
tor-android/external/tor/src/core/mainloop/mainloop.c
Replace original file for Android build only!


----------------------Android----------------------------------

Download and unzip NDK:
http://dl.google.com/android/ndk/android-ndk-r9c-linux-x86.tar.bz2

Set ANDROID_NDK_HOME  to NDK path (for example /opt/android-ndk) in Makefile

Replace defautl Makefile by our:
tor-android/external/Makefile


Build:

cd tor-android/external
make


The result elf is:
tor-android/external/bin/libTor.so

----------------Linux-----------------------------------

This source can be use for staticallu build Tor for Linux.
Rename Makefile-linux  to Makefile (overwrite)
Build:

cd tor-android/external
make

The result elf is: 
tor-android/external/bin/tf_tor

